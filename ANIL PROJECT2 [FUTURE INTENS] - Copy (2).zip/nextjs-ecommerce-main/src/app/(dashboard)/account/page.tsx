import React from 'react'

export default function Account() {
  return (
    <div>Account</div>
  )
}
