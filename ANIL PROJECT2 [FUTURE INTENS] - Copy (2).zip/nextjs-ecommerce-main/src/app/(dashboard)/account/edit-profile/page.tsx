import React from "react";
import AccountUpdateForm from "./AccountUpdateForm";

export default function EditProfile() {
	return (
		<AccountUpdateForm/>
	);
}
